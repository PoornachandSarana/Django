from django.db import models


class Recipe(models.Model):
    CUISINE_CHOICES = [
        ('Mexican', 'Mexican'),
        ('Chinese', 'Chinese'),
        ('Korean', 'Korean'),
        # Add more cuisine options as needed
    ]

    name = models.CharField(max_length=200)
    cuisine_type = models.CharField(max_length=50, choices=CUISINE_CHOICES)
    is_vegetarian = models.BooleanField(default=False)
    ingredients = models.TextField()
    cooking_time = models.PositiveIntegerField(help_text="Cooking time in minutes")
    servings = models.PositiveIntegerField()
    image = models.ImageField(upload_to='recipe_images/', blank=True, null=True)
    preparation_steps = models.TextField()
    notes = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name


from django.db import models

# Create your models here.
